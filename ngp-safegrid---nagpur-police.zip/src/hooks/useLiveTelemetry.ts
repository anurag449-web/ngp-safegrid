import { useState, useEffect, useCallback, useRef } from 'react';
import { PoliceStation, CrimeHotspot, NetworkNode, NetworkEdge } from '../types';
import {
  POLICE_STATIONS,
  CRIME_HOTSPOTS,
  NETWORK_NODES,
  NETWORK_EDGES,
  DUMMY_CRIMINAL_NODES,
  DUMMY_NETWORK_EDGES,
  ADDITIONAL_CRIME_HOTSPOTS,
} from '../data/mockData';

export interface StatMetrics {
  totalCases: number;
  casesChange: string;
  extortionCases: number;
  mcocaCases: number;
  narcoticsCases: number;
  activeGangs: number;
  wiretappedGangs: number;
  recentGangDetected: string | null;
  sitabuldiRisk: number;
  sitabuldiPatrols: number;
  sitabuldiThreatLevel: string;
  lastUpdatedText: string;
  isUpdating: boolean;
}

export interface LiveFeedNotification {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'FIR' | 'INTERCEPT' | 'FINANCIAL' | 'HOTSPOT' | 'PATROL';
}

export function useLiveTelemetry(onNewAlert?: (msg: string) => void) {
  // Cards Metrics State
  const [metrics, setMetrics] = useState<StatMetrics>({
    totalCases: 128,
    casesChange: '+12 this mo',
    extortionCases: 48,
    mcocaCases: 34,
    narcoticsCases: 46,
    activeGangs: 7,
    wiretappedGangs: 4,
    recentGangDetected: null,
    sitabuldiRisk: 80,
    sitabuldiPatrols: 6,
    sitabuldiThreatLevel: 'CRITICAL',
    lastUpdatedText: 'Live Feed Connected',
    isUpdating: false,
  });

  // Dynamic Map & Graph Entities State
  const [stations, setStations] = useState<PoliceStation[]>(POLICE_STATIONS);
  const [hotspots, setHotspots] = useState<CrimeHotspot[]>(CRIME_HOTSPOTS);
  const [nodes, setNodes] = useState<NetworkNode[]>(NETWORK_NODES);
  const [edges, setEdges] = useState<NetworkEdge[]>(NETWORK_EDGES);

  // Highlighting flags for newly appeared items
  const [newestNodeId, setNewestNodeId] = useState<string | null>(null);
  const [newestEdgeId, setNewestEdgeId] = useState<string | null>(null);
  const [newestHotspotId, setNewestHotspotId] = useState<string | null>(null);

  // Simulation Controls
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [stepIndex, setStepIndex] = useState<number>(0);
  const [tickerText, setTickerText] = useState<string>(
    '[LIVE SECURE FEED ACTIVE] Monitoring Sitabuldi, Ganeshpeth & Kotwali Jurisdictions • Intercept links running'
  );

  const [recentNotification, setRecentNotification] = useState<LiveFeedNotification | null>(null);

  // Helper to trigger card flash effect
  const flashCards = () => {
    setMetrics((prev) => ({ ...prev, isUpdating: true }));
    setTimeout(() => {
      setMetrics((prev) => ({ ...prev, isUpdating: false }));
    }, 1200);
  };

  // Step advancement logic
  const advanceSimulation = useCallback(
    (targetStep?: number) => {
      const nextStep = typeof targetStep === 'number' ? targetStep : (stepIndex + 1) % 6;
      setStepIndex(nextStep);
      flashCards();

      const timeString = new Date().toLocaleTimeString('en-US', {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });

      switch (nextStep) {
        case 0: {
          // Reset to pristine baseline
          setMetrics({
            totalCases: 128,
            casesChange: '+12 this mo',
            extortionCases: 48,
            mcocaCases: 34,
            narcoticsCases: 46,
            activeGangs: 7,
            wiretappedGangs: 4,
            recentGangDetected: null,
            sitabuldiRisk: 80,
            sitabuldiPatrols: 6,
            sitabuldiThreatLevel: 'CRITICAL',
            lastUpdatedText: `Refreshed at ${timeString}`,
            isUpdating: true,
          });
          setStations(POLICE_STATIONS);
          setHotspots(CRIME_HOTSPOTS);
          setNodes(NETWORK_NODES);
          setEdges(NETWORK_EDGES);
          setNewestNodeId(null);
          setNewestEdgeId(null);
          setNewestHotspotId(null);
          setTickerText(
            `[${timeString}] Baseline synchronized with Nagpur Control Room • Sitabuldi High Alert 80%`
          );
          break;
        }

        case 1: {
          // Event 1: New crime dot appears at Tekdi Road Railway Outer, Total Cases increases 128 -> 129
          const newHs = ADDITIONAL_CRIME_HOTSPOTS[0]; // hs-6: Tekdi Road Railway Outer
          setHotspots((prev) => {
            if (prev.some((h) => h.id === newHs.id)) return prev;
            return [...prev, newHs];
          });
          setNewestHotspotId(newHs.id);

          // Update Sitabuldi Station FIRs
          setStations((prev) =>
            prev.map((s) =>
              s.id === 'ps-sitabuldi' ? { ...s, currentFIRs: s.currentFIRs + 1, activePatrols: 7 } : s
            )
          );

          setMetrics((prev) => ({
            ...prev,
            totalCases: 129,
            casesChange: '+13 this mo',
            extortionCases: 49,
            sitabuldiRisk: 82,
            sitabuldiPatrols: 7,
            lastUpdatedText: `New FIR registered (${timeString})`,
          }));

          const alertMsg = 'CRIME REPORT: New Armed Extortion incident plotted at Tekdi Road Outer';
          setTickerText(
            `[${timeString}] DOCKET LOGGED: FIR #320/2026 registered at Sitabuldi PS // Tekdi Road Outer Hotspot Active`
          );
          setRecentNotification({
            id: 'notif-1',
            title: 'New Incident Plotted',
            message: 'Tekdi Road Railway Outer added to Sitabuldi Live Map (+1 Extortion FIR)',
            time: timeString,
            type: 'HOTSPOT',
          });
          onNewAlert?.(alertMsg);
          break;
        }

        case 2: {
          // Event 2: New dummy criminal node appears: Vicky - Dharampeth & Call Record connection to Ravi
          const vickyNode = DUMMY_CRIMINAL_NODES[0]; // node-vicky
          const vickyEdge = DUMMY_NETWORK_EDGES[0]; // edge-ravi-vicky (Call Record)

          setNodes((prev) => {
            if (prev.some((n) => n.id === vickyNode.id)) return prev;
            return [...prev, vickyNode];
          });
          setEdges((prev) => {
            if (prev.some((e) => e.id === vickyEdge.id)) return prev;
            return [...prev, vickyEdge];
          });
          setNewestNodeId(vickyNode.id);
          setNewestEdgeId(vickyEdge.id);

          setMetrics((prev) => ({
            ...prev,
            activeGangs: 8,
            wiretappedGangs: 5,
            recentGangDetected: 'Dharampeth Supply Cell',
            sitabuldiRisk: 84,
            lastUpdatedText: `Network Expanded (${timeString})`,
          }));

          const alertMsg = 'WIRETAP INTERCEPT: Vicky (Dharampeth) linked to Target Alpha (Ravi)';
          setTickerText(
            `[${timeString}] LIVE CDR INTERCEPT: 42 burst calls detected between Ravi (Main) and Vicky - Dharampeth`
          );
          setRecentNotification({
            id: 'notif-2',
            title: 'Criminal Node Mapped',
            message: 'Vicky - Dharampeth identified as Arms Courier; direct call record established with Ravi',
            time: timeString,
            type: 'INTERCEPT',
          });
          onNewAlert?.(alertMsg);
          break;
        }

        case 3: {
          // Event 3: Cyber / Hawala Mule Pooja - Sadar appears, linked to Amit - Itwari via Financial Conduit
          const poojaNode = DUMMY_CRIMINAL_NODES[1]; // node-pooja
          const amitPoojaEdge = DUMMY_NETWORK_EDGES[1]; // edge-amit-pooja (Financial Conduit)
          const newHotspot2 = ADDITIONAL_CRIME_HOTSPOTS[1]; // hs-7: Itwari Sarafa

          setNodes((prev) => {
            if (prev.some((n) => n.id === poojaNode.id)) return prev;
            return [...prev, poojaNode];
          });
          setEdges((prev) => {
            if (prev.some((e) => e.id === amitPoojaEdge.id)) return prev;
            return [...prev, amitPoojaEdge];
          });
          setHotspots((prev) => {
            if (prev.some((h) => h.id === newHotspot2.id)) return prev;
            return [...prev, newHotspot2];
          });
          setNewestNodeId(poojaNode.id);
          setNewestEdgeId(amitPoojaEdge.id);
          setNewestHotspotId(newHotspot2.id);

          setMetrics((prev) => ({
            ...prev,
            totalCases: 131,
            mcocaCases: 35,
            sitabuldiRisk: 85,
            lastUpdatedText: `Hawala Conduit Mapped (${timeString})`,
          }));

          const alertMsg = 'FINANCIAL LINK TRACED: Amit - Itwari linked to Pooja - Sadar (₹45L Mules)';
          setTickerText(
            `[${timeString}] CYBER & HAWALA CELL: ₹45L digital money laundering conduit mapped between Itwari & Sadar`
          );
          setRecentNotification({
            id: 'notif-3',
            title: 'Financial Pipeline Flagged',
            message: 'Pooja - Sadar linked to Amit - Itwari via 6 shell QR mule accounts',
            time: timeString,
            type: 'FINANCIAL',
          });
          onNewAlert?.(alertMsg);
          break;
        }

        case 4: {
          // Event 4: Raju - Tekdi Road appears with Same FIR connection to Ravi, and Sunil connects to Vicky (Weapons Supply)
          const rajuNode = DUMMY_CRIMINAL_NODES[2]; // node-raju
          const raviRajuEdge = DUMMY_NETWORK_EDGES[2]; // edge-ravi-raju (Same FIR)
          const sunilVickyEdge = DUMMY_NETWORK_EDGES[3]; // edge-sunil-vicky (Weapons Supply)
          const poojaGangEdge = DUMMY_NETWORK_EDGES[4]; // edge-pooja-gang (Same FIR)

          setNodes((prev) => {
            if (prev.some((n) => n.id === rajuNode.id)) return prev;
            return [...prev, rajuNode];
          });
          setEdges((prev) => {
            const existingIds = new Set(prev.map((e) => e.id));
            const toAdd = [raviRajuEdge, sunilVickyEdge, poojaGangEdge].filter((e) => !existingIds.has(e.id));
            return [...prev, ...toAdd];
          });
          setNewestNodeId(rajuNode.id);
          setNewestEdgeId(raviRajuEdge.id);

          setMetrics((prev) => ({
            ...prev,
            totalCases: 133,
            casesChange: '+17 this mo',
            extortionCases: 51,
            sitabuldiRisk: 88,
            sitabuldiPatrols: 8,
            lastUpdatedText: `High Alert Escalation (${timeString})`,
          }));

          const alertMsg = 'MCOCA AMENDMENT: Raju - Tekdi Road booked under FIR #312/2026; 3 New Edges Formed';
          setTickerText(
            `[${timeString}] SYNDICATE CONVERGENCE: Raju (Tekdi Rd) & Vicky (Dharampeth) multi-node links verified`
          );
          setRecentNotification({
            id: 'notif-4',
            title: 'Syndicate Nodes Converging',
            message: 'Raju - Tekdi Road co-booked under FIR #312/2026; weapons conduit confirmed with Sunil',
            time: timeString,
            type: 'FIR',
          });
          onNewAlert?.(alertMsg);
          break;
        }

        case 5: {
          // Event 5: Police Counter-Operation, 8 QRT Vans Deployed, Dharampeth Hotspot flagged, Threat Stabilizing
          const newHotspot3 = ADDITIONAL_CRIME_HOTSPOTS[2]; // hs-8: Dharampeth
          setHotspots((prev) => {
            if (prev.some((h) => h.id === newHotspot3.id)) return prev;
            return [...prev, newHotspot3];
          });
          setNewestHotspotId(newHotspot3.id);

          setStations((prev) =>
            prev.map((s) => ({
              ...s,
              activePatrols: s.id === 'ps-sitabuldi' ? 8 : s.id === 'ps-ganeshpeth' ? 6 : 4,
            }))
          );

          setMetrics((prev) => ({
            ...prev,
            totalCases: 133,
            sitabuldiRisk: 81,
            sitabuldiPatrols: 8,
            sitabuldiThreatLevel: 'CONTROLLED_ALERT',
            lastUpdatedText: `Surge Deployed (${timeString})`,
          }));

          const alertMsg = 'PATROL SURGE DEPLOYED: 8 QRT Vans actively blockading Sitabuldi & Variety Square';
          setTickerText(
            `[${timeString}] COMMAND DISPATCH: Full tactical perimeter set around Variety Square and Tekdi Road`
          );
          setRecentNotification({
            id: 'notif-5',
            title: 'QRT Patrol Surge',
            message: '8 Quick Response Vans deployed across Zone II & III; Sitabuldi risk score cooled to 81%',
            time: timeString,
            type: 'PATROL',
          });
          onNewAlert?.(alertMsg);
          break;
        }

        default:
          break;
      }
    },
    [stepIndex, onNewAlert]
  );

  // Auto-simulation timer interval (every 7.5 seconds)
  useEffect(() => {
    if (!isSimulating) return;

    const timer = setInterval(() => {
      advanceSimulation();
    }, 7500);

    return () => clearInterval(timer);
  }, [isSimulating, advanceSimulation]);

  // Clean up newest highlighted indicators after 3.5 seconds
  useEffect(() => {
    if (!newestNodeId && !newestEdgeId && !newestHotspotId) return;
    const timeout = setTimeout(() => {
      setNewestNodeId(null);
      setNewestEdgeId(null);
      setNewestHotspotId(null);
    }, 3500);
    return () => clearTimeout(timeout);
  }, [newestNodeId, newestEdgeId, newestHotspotId]);

  const toggleSimulation = () => {
    setIsSimulating((prev) => !prev);
  };

  const triggerNextEvent = () => {
    advanceSimulation();
  };

  const resetSimulation = () => {
    advanceSimulation(0);
  };

  return {
    metrics,
    stations,
    hotspots,
    nodes,
    edges,
    newestNodeId,
    newestEdgeId,
    newestHotspotId,
    isSimulating,
    stepIndex,
    tickerText,
    recentNotification,
    toggleSimulation,
    triggerNextEvent,
    resetSimulation,
  };
}
