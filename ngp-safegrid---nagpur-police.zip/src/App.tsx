import React, { useState } from 'react';
import { Header } from './components/Header';
import { StatCards } from './components/StatCards';
import { LiveCrimeMap } from './components/LiveCrimeMap';
import { CriminalNetworkGraph } from './components/CriminalNetworkGraph';
import { AiHotspotPredictor } from './components/AiHotspotPredictor';
import { DossierModal } from './components/DossierModal';
import { SitRepModal } from './components/SitRepModal';
import { NetworkNode, PoliceStation, CrimeHotspot } from './types';
import { Bell, CheckCircle2, Shield, Radio, Terminal, Play, Pause, FastForward, Activity } from 'lucide-react';
import { useLiveTelemetry } from './hooks/useLiveTelemetry';

export default function App() {
  const [selectedNode, setSelectedNode] = useState<NetworkNode | null>(null);
  const [selectedStation, setSelectedStation] = useState<PoliceStation | null>(null);
  const [selectedHotspot, setSelectedHotspot] = useState<CrimeHotspot | null>(null);
  const [showSitRep, setShowSitRep] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);

  // Live Telemetry simulation state & reactive stream
  const {
    metrics,
    stations,
    hotspots,
    nodes,
    edges,
    tickerText,
    isSimulating,
    toggleSimulation,
    triggerNextEvent,
    newestNodeId,
    newestEdgeId,
    newestHotspotId,
  } = useLiveTelemetry();

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const handleCardClick = (cardId: string) => {
    setSelectedCardId(cardId);
    if (cardId === 'alert') {
      showToast(`SITABULDI PS JURISDICTION HIGHLIGHTED: Threat level ${metrics.sitabuldiRisk}% CRITICAL`);
    } else if (cardId === 'gangs') {
      showToast(`CRIMINAL NETWORK MATRIX HIGHLIGHTED: ${metrics.activeGangs} Gangs monitored under MCOCA`);
    } else if (cardId === 'cases') {
      showToast(`DOCKET ARCHIVE LOADED: ${metrics.totalCases} registered case files in Zone II & III`);
    }
  };

  const handleForceTelemetryStep = () => {
    triggerNextEvent();
    showToast('Simulated Next Live Event: Telemetry stream updated with fresh Crime Branch intel');
  };

  return (
    <div className="min-h-screen bg-black text-zinc-100 flex flex-col selection:bg-blue-600 selection:text-white relative">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-18 right-4 sm:right-8 z-50 animate-in slide-in-from-top-4 duration-200">
          <div className="flex items-center gap-3 px-4 py-3 rounded-lg bg-zinc-900 border-2 border-blue-500 text-white shadow-2xl shadow-blue-950 font-mono-code text-xs">
            <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
            <span>{toastMessage}</span>
            <button
              onClick={() => setToastMessage(null)}
              className="text-zinc-400 hover:text-white ml-2 text-sm font-bold"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* PAGE 1: TOP HEADER */}
      <Header
        onRefresh={() => {
          handleForceTelemetryStep();
        }}
        onViewReport={() => setShowSitRep(true)}
        alertCount={metrics.sitabuldiRisk >= 85 ? 4 : 3}
      />

      {/* MAIN DASHBOARD CONTENT AREA */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6 sm:space-y-8">
        
        {/* Real-time Ticker Strip with Live Telemetry Controls */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 px-3.5 py-2 rounded-lg bg-zinc-950 border border-zinc-800 text-xs font-mono-code overflow-hidden shadow-md">
          <div className="flex items-center gap-2 shrink-0">
            <span className={`w-2.5 h-2.5 rounded-full ${isSimulating ? 'bg-emerald-500 animate-ping' : 'bg-amber-500'}`} />
            <span className="font-bold text-red-400 uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-blue-400" />
              LIVE TELEMETRY:
            </span>
          </div>
          
          <div className="flex-1 text-zinc-300 truncate w-full sm:w-auto px-2">
            <span className="text-blue-300 font-semibold">{tickerText}</span>
          </div>

          {/* Interactive Simulation Controls */}
          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
            <button
              onClick={toggleSimulation}
              className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-mono-code transition-colors border ${
                isSimulating
                  ? 'bg-emerald-950/70 border-emerald-700 text-emerald-300 hover:bg-emerald-900'
                  : 'bg-zinc-800 border-zinc-700 text-zinc-400 hover:text-white'
              }`}
              title={isSimulating ? 'Pause Automatic 7.5s Stream' : 'Resume Live Stream'}
            >
              {isSimulating ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              <span>{isSimulating ? 'Auto: ON' : 'Paused'}</span>
            </button>

            <button
              onClick={handleForceTelemetryStep}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-blue-950 hover:bg-blue-900 border border-blue-700 text-blue-200 text-[11px] font-mono-code font-bold transition-all shadow"
              title="Immediately advance simulation step to add dummy criminal node or refresh cards"
            >
              <FastForward className="w-3 h-3 text-blue-400" />
              <span>Simulate Next Intel</span>
            </button>
          </div>
        </div>

        {/* PAGE 2: 3 CARDS IN A ROW (Real-Time Refreshing) */}
        <StatCards
          selectedCard={selectedCardId}
          onSelectCard={handleCardClick}
          metrics={metrics}
          onRefreshClick={handleForceTelemetryStep}
        />

        {/* PAGE 3: SPLIT IN 2 COLUMNS */}
        <section id="intel-grid-split" className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
          {/* Left Column: Live Crime Map - Nagpur */}
          <div className="h-full min-h-[500px]">
            <LiveCrimeMap
              onSelectStation={(st) => setSelectedStation(st)}
              onSelectHotspot={(hs) => setSelectedHotspot(hs)}
              selectedStationId={selectedStation?.id}
              selectedHotspotId={selectedHotspot?.id}
              stations={stations}
              hotspots={hotspots}
              newestHotspotId={newestHotspotId}
            />
          </div>

          {/* Right Column: Criminal Network Link (FBI Graph) */}
          <div className="h-full min-h-[500px]">
            <CriminalNetworkGraph
              onSelectNode={(node) => setSelectedNode(node)}
              selectedNodeId={selectedNode?.id}
              nodes={nodes}
              edges={edges}
              newestNodeId={newestNodeId}
              newestEdgeId={newestEdgeId}
            />
          </div>
        </section>

        {/* PAGE 4: BOTTOM BIG BLUE BUTTON */}
        <AiHotspotPredictor
          onDispatchSuccess={(msg) => showToast(msg)}
          onFocusSitabuldi={() => {
            setSelectedCardId('alert');
            showToast(`AI Model localized: Sitabuldi PS High Risk Hotspot Analyzed (${metrics.sitabuldiRisk}% Threat)`);
          }}
        />

      </main>

      {/* FOOTER */}
      <footer className="border-t border-zinc-900 bg-zinc-950 py-4 px-6 text-center text-xs text-zinc-500 font-mono-code">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Shield className="w-3.5 h-3.5 text-blue-500" />
            <span>NGP SafeGrid // Nagpur Police Criminal Network Intelligence Platform</span>
          </div>
          <div className="text-zinc-600 text-[11px]">
            Hackathon Prototype • Zone II &amp; III Crime Branch Operations • 256-Bit Encrypted
          </div>
        </div>
      </footer>

      {/* Suspect / Station / Hotspot Intelligence Dossier Modal */}
      <DossierModal
        node={selectedNode}
        station={selectedStation}
        hotspot={selectedHotspot}
        onClose={() => {
          setSelectedNode(null);
          setSelectedStation(null);
          setSelectedHotspot(null);
        }}
      />

      {/* Daily SitRep Modal */}
      {showSitRep && <SitRepModal onClose={() => setShowSitRep(false)} />}
    </div>
  );
}
