export interface PoliceStation {
  id: string;
  name: string;
  code: string;
  lat: number;
  lng: number;
  xPercent: number; // For map representation
  yPercent: number;
  status: 'HIGH_ALERT' | 'NORMAL' | 'ELEVATED';
  activePatrols: number;
  inCharge: string;
  jurisdictionArea: string;
  currentFIRs: number;
  phone: string;
}

export interface CrimeHotspot {
  id: string;
  locationName: string;
  nearStation: string;
  severity: 'CRITICAL' | 'HIGH' | 'MODERATE';
  xPercent: number;
  yPercent: number;
  recentIncidents: number;
  primaryCrimeType: string;
  peakHours: string;
  riskScore: number;
}

export interface NetworkNode {
  id: string;
  name: string;
  role: string;
  alias?: string;
  location: string;
  type: 'LEADER' | 'OPERATIVE' | 'ORGANIZATION';
  isRedCenter?: boolean;
  isBox?: boolean;
  status: 'WANTED' | 'UNDER_SURVEILLANCE' | 'ACTIVE_CELL';
  firs: string[];
  mcoCaBooked: boolean;
  riskRating: string;
  interceptsLogged: number;
  notes: string;
}

export interface NetworkEdge {
  id: string;
  from: string;
  to: string;
  label: 'Call Record' | 'Same FIR' | 'Financial Conduit' | 'Weapons Supply';
  details: string;
  frequency?: string;
  firNumber?: string;
}

export interface HotspotPrediction {
  targetLocation: string;
  targetStation: string;
  riskPercentage: number;
  threatLevel: 'CRITICAL' | 'SEVERE' | 'ELEVATED';
  timeframe: string;
  keyDrivers: string[];
  recommendedDeployment: {
    units: string;
    action: string;
    checkpoints: string[];
  };
}
