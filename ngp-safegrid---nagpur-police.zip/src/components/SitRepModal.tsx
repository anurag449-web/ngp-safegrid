import React from 'react';
import { X, FileText, CheckCircle, AlertTriangle, Shield, Clock } from 'lucide-react';

interface SitRepModalProps {
  onClose: () => void;
}

export const SitRepModal: React.FC<SitRepModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-zinc-900 border-2 border-zinc-700 rounded-xl shadow-2xl overflow-hidden font-mono-code">
        {/* Header */}
        <div className="bg-zinc-950 border-b border-zinc-800 p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-400" />
            <span className="text-sm font-bold text-white uppercase tracking-wider">
              DAILY SITREP // NAGPUR CRIME BRANCH
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-white p-1 rounded hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 text-xs text-zinc-300 max-h-[75vh] overflow-y-auto">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800 text-zinc-400">
            <span>DISPATCH REF: NGP-CP-2026-0913</span>
            <span>CLASSIFICATION: SECRET</span>
          </div>

          <div className="bg-red-950/40 border border-red-900/80 p-3 rounded text-red-200">
            <div className="font-bold flex items-center gap-2 mb-1 text-red-300">
              <AlertTriangle className="w-4 h-4" />
              SITABULDI PS: RED THREAT CONDITION ACTIVE
            </div>
            <p className="leading-relaxed">
              Target syndicate led by Ravi (Main) active in extortion attempts near Sitabuldi Metro Corridor. Wiretaps indicate financial settlement meeting arranged tonight between Amit (Itwari) and ground operatives.
            </p>
          </div>

          <div>
            <div className="text-zinc-400 font-bold uppercase mb-2">Key Tactical Directives:</div>
            <ul className="space-y-2 list-disc list-inside text-zinc-300">
              <li>Deploy Static Barricades at Variety Square and Munje Square (Sitabuldi PS).</li>
              <li>Surveillance team assigned to monitor CBS terminal bus exits (Ganeshpeth PS).</li>
              <li>Coordinate with Kotwali PS for Itwari bullion market night sweeps.</li>
              <li>Active MCOCA dockets to be presented to Special Court tomorrow 10:30 HRS.</li>
            </ul>
          </div>

          <div className="pt-3 border-t border-zinc-800 flex justify-between items-center text-[11px] text-zinc-500">
            <span>Approved by: Commissioner of Police, Nagpur</span>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded"
            >
              Acknowledge Briefing
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
