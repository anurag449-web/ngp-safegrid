import React from 'react';
import { AlertTriangle, Users, FileSpreadsheet, ShieldAlert, TrendingUp, Radar, Radio, RefreshCw } from 'lucide-react';
import { StatMetrics } from '../hooks/useLiveTelemetry';

interface StatCardsProps {
  onSelectCard?: (cardId: string) => void;
  selectedCard?: string | null;
  metrics?: StatMetrics;
  onRefreshClick?: () => void;
}

export const StatCards: React.FC<StatCardsProps> = ({
  onSelectCard,
  selectedCard,
  metrics = {
    totalCases: 128,
    casesChange: '+12 this mo',
    extortionCases: 48,
    mcocaCases: 34,
    narcoticsCases: 46,
    activeGangs: 7,
    wiretappedGangs: 4,
    recentGangDetected: null,
    sitabuldiRisk: 80,
    sitabuldiPatrols: 6,
    sitabuldiThreatLevel: 'CRITICAL',
    lastUpdatedText: 'Live Stream Connected',
    isUpdating: false,
  },
  onRefreshClick,
}) => {
  const {
    totalCases,
    casesChange,
    extortionCases,
    mcocaCases,
    narcoticsCases,
    activeGangs,
    wiretappedGangs,
    recentGangDetected,
    sitabuldiRisk,
    sitabuldiPatrols,
    lastUpdatedText,
    isUpdating,
  } = metrics;

  return (
    <section id="metrics-section" className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6">
      {/* Card 1: Total Cases 128 (Periodically Refreshes) */}
      <div
        id="card-total-cases"
        onClick={() => onSelectCard?.('cases')}
        className={`group relative rounded-xl bg-zinc-900 border ${
          selectedCard === 'cases'
            ? 'border-blue-500 ring-2 ring-blue-500/20'
            : isUpdating
            ? 'border-blue-400/80 ring-1 ring-blue-400/30'
            : 'border-zinc-800'
        } hover:border-zinc-700 p-5 lg:p-6 transition-all duration-300 cursor-pointer shadow-lg overflow-hidden`}
      >
        {/* Subtle grid accent */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono-code text-zinc-400 uppercase tracking-wider">
                Docket Register // Central Nagpur
              </span>
              <span className="px-1.5 py-0.5 text-[10px] font-mono-code bg-blue-950 text-blue-300 border border-blue-800/60 rounded flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
                CR-2026
              </span>
            </div>
            <h2 className="text-lg font-semibold text-zinc-200 mt-1">Total Cases</h2>
          </div>
          <div className="p-2.5 rounded-lg bg-zinc-800/90 border border-zinc-700/60 text-blue-400 flex items-center justify-center">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
        </div>

        {/* Big Number with live update transition */}
        <div className="mt-4 flex items-baseline gap-3">
          <span
            className={`text-4xl lg:text-5xl font-bold font-display tracking-tight transition-colors duration-300 ${
              isUpdating ? 'text-blue-300 scale-105 transition-transform' : 'text-white'
            }`}
          >
            {totalCases}
          </span>
          <span className="flex items-center gap-1 text-xs font-medium text-emerald-400 font-mono-code">
            <TrendingUp className="w-3.5 h-3.5" />
            {casesChange}
          </span>
          {isUpdating && (
            <span className="text-[10px] font-mono-code px-1.5 py-0.2 rounded bg-blue-900/60 border border-blue-600 text-blue-300 animate-pulse">
              LIVE +1
            </span>
          )}
        </div>

        {/* Category Breakdown Bar */}
        <div className="mt-4 pt-3 border-t border-zinc-800/80">
          <div className="flex justify-between text-xs text-zinc-400 mb-1.5 font-mono-code">
            <span>Extortion: {extortionCases}</span>
            <span>MCOCA: {mcocaCases}</span>
            <span>Narcotics: {narcoticsCases}</span>
          </div>
          <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden flex">
            <div
              className="h-full bg-blue-500 transition-all duration-500"
              style={{ width: `${(extortionCases / totalCases) * 100}%` }}
              title={`Extortion: ${extortionCases}`}
            />
            <div
              className="h-full bg-amber-500 transition-all duration-500"
              style={{ width: `${(mcocaCases / totalCases) * 100}%` }}
              title={`MCOCA: ${mcocaCases}`}
            />
            <div
              className="h-full bg-red-500 transition-all duration-500"
              style={{ width: `${(narcoticsCases / totalCases) * 100}%` }}
              title={`Narcotics/Arms: ${narcoticsCases}`}
            />
          </div>
          <p className="mt-2 text-[11px] text-zinc-500 flex items-center justify-between">
            <span>{totalCases - 42} Under Active Investigation</span>
            <span className="text-blue-400 underline font-mono-code">View Dockets &rarr;</span>
          </p>
        </div>
      </div>

      {/* Card 2: Active Gangs 7 (Periodically Refreshes) */}
      <div
        id="card-active-gangs"
        onClick={() => onSelectCard?.('gangs')}
        className={`group relative rounded-xl bg-zinc-900 border ${
          selectedCard === 'gangs'
            ? 'border-amber-500 ring-2 ring-amber-500/20'
            : isUpdating
            ? 'border-amber-400/80 ring-1 ring-amber-400/30'
            : 'border-zinc-800'
        } hover:border-zinc-700 p-5 lg:p-6 transition-all duration-300 cursor-pointer shadow-lg overflow-hidden`}
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono-code text-zinc-400 uppercase tracking-wider">
                Organized Crime Cell
              </span>
              <span className="px-1.5 py-0.5 text-[10px] font-mono-code bg-amber-950 text-amber-300 border border-amber-800/60 rounded flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                MAPPED
              </span>
            </div>
            <h2 className="text-lg font-semibold text-zinc-200 mt-1">Active Gangs</h2>
          </div>
          <div className="p-2.5 rounded-lg bg-zinc-800/90 border border-zinc-700/60 text-amber-400">
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* Big Number with live update transition */}
        <div className="mt-4 flex items-baseline gap-3">
          <span
            className={`text-4xl lg:text-5xl font-bold font-display tracking-tight transition-colors duration-300 ${
              isUpdating ? 'text-amber-300 scale-105 transition-transform' : 'text-white'
            }`}
          >
            {activeGangs}
          </span>
          <span className="flex items-center gap-1 text-xs font-medium text-amber-400 font-mono-code">
            <Radar className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '6s' }} />
            {wiretappedGangs} Under Wiretap
          </span>
          {recentGangDetected && (
            <span className="text-[10px] font-mono-code px-1.5 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-800 animate-pulse">
              +1 CELL DETECTED
            </span>
          )}
        </div>

        {/* Syndicate Tags */}
        <div className="mt-4 pt-3 border-t border-zinc-800/80">
          <div className="flex flex-wrap gap-1.5 text-[11px] font-mono-code">
            <span className="px-2 py-0.5 bg-red-950/80 text-red-300 border border-red-900/60 rounded">
              Sitabuldi Syndicate
            </span>
            <span className="px-2 py-0.5 bg-zinc-800 text-zinc-300 border border-zinc-700/60 rounded">
              Itwari Hawala Ring
            </span>
            <span className="px-2 py-0.5 bg-zinc-800 text-zinc-300 border border-zinc-700/60 rounded">
              CBS Smuggling Unit
            </span>
            {activeGangs > 7 && (
              <span className="px-2 py-0.5 bg-amber-950/80 text-amber-300 border border-amber-700/60 rounded animate-pulse">
                Dharampeth Nexus
              </span>
            )}
          </div>
          <p className="mt-2 text-[11px] text-zinc-500 flex items-center justify-between">
            <span>Focus: Ravi (Main) Network</span>
            <span className="text-amber-400 underline font-mono-code">View Dossiers &rarr;</span>
          </p>
        </div>
      </div>

      {/* Card 3: High Alert Sitabuldi PS with red background (Periodically Refreshes) */}
      <div
        id="card-high-alert-sitabuldi"
        onClick={() => onSelectCard?.('alert')}
        className={`group relative rounded-xl bg-red-950/85 border-2 ${
          selectedCard === 'alert'
            ? 'border-red-400 ring-4 ring-red-500/40'
            : isUpdating
            ? 'border-red-400 ring-2 ring-red-400/40'
            : 'border-red-600 hover:border-red-500'
        } p-5 lg:p-6 transition-all duration-300 cursor-pointer shadow-2xl shadow-red-950/60 overflow-hidden`}
      >
        {/* Pulsing red beacon halo */}
        <div className="absolute -top-12 -right-12 w-40 h-40 bg-red-600/30 rounded-full blur-3xl animate-pulse pointer-events-none" />

        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[11px] font-bold font-mono-code bg-red-600 text-white rounded uppercase tracking-wider animate-pulse">
                <AlertTriangle className="w-3.5 h-3.5" />
                CRITICAL THREAT
              </span>
              <span className="text-[10px] font-mono-code text-red-300">ZONE II</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1.5 flex items-center gap-2 font-display">
              High Alert Sitabuldi PS
            </h2>
          </div>
          <div className="p-2.5 rounded-lg bg-red-900/90 border border-red-500/80 text-white shadow-md">
            <ShieldAlert className="w-5 h-5 text-red-200 animate-bounce" />
          </div>
        </div>

        {/* Threat Level Metrics with live dynamic risk % */}
        <div className="mt-4 flex items-baseline justify-between">
          <div>
            <span className="text-xs font-mono-code text-red-200 uppercase">Jurisdiction Risk Index</span>
            <div className="text-3xl lg:text-4xl font-black font-display text-white tracking-tight flex items-baseline gap-1">
              <span className={isUpdating ? 'text-red-300' : 'text-white'}>{sitabuldiRisk}%</span>
              <span className="text-base font-normal text-red-200">MAX</span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs font-mono-code text-red-200 uppercase">QRT Deployment</span>
            <div className="flex items-center justify-end gap-1.5 text-sm font-semibold text-white mt-0.5">
              <Radio className="w-4 h-4 text-white animate-pulse" />
              <span>{sitabuldiPatrols} Vans Active</span>
            </div>
          </div>
        </div>

        {/* Alert Details */}
        <div className="mt-4 pt-3 border-t border-red-800/80">
          <p className="text-xs text-red-100/90 leading-relaxed font-medium">
            Imminent extortion retaliation predicted near Variety Square & Metro Interchange. Quick Response Teams on stand-by.
          </p>
          <div className="mt-2.5 flex items-center justify-between text-[11px] font-mono-code text-red-200">
            <span className="underline font-bold hover:text-white flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-ping" />
              {lastUpdatedText}
            </span>
            <span className="px-2 py-0.5 bg-black/40 rounded border border-red-500/50">SEC 144 ADVISORY</span>
          </div>
        </div>
      </div>
    </section>
  );
};

