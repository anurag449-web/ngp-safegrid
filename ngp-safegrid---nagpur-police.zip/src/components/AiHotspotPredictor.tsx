import React, { useState } from 'react';
import { Cpu, AlertTriangle, ShieldCheck, Zap, Radio, CheckCircle2, ChevronUp, ChevronDown, MapPin, Clock, ArrowRight } from 'lucide-react';
import { HOTSPOT_PREDICTION } from '../data/mockData';

interface AiHotspotPredictorProps {
  onDispatchSuccess?: (message: string) => void;
  onFocusSitabuldi?: () => void;
}

export const AiHotspotPredictor: React.FC<AiHotspotPredictorProps> = ({
  onDispatchSuccess,
  onFocusSitabuldi,
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(true);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [dispatchStatus, setDispatchStatus] = useState<'IDLE' | 'DISPATCHING' | 'DISPATCHED'>('IDLE');

  const handlePredictClick = () => {
    setIsSimulating(true);
    setTimeout(() => {
      setIsSimulating(false);
      setIsExpanded(true);
      onFocusSitabuldi?.();
    }, 450);
  };

  const handleDispatch = () => {
    setDispatchStatus('DISPATCHING');
    setTimeout(() => {
      setDispatchStatus('DISPATCHED');
      onDispatchSuccess?.('PCR-04 & Cheetah Squads deployed to Sitabuldi Variety Chowk. Sec 144 advisory transmitted.');
    }, 1000);
  };

  return (
    <section id="ai-predictor-section" className="space-y-4">
      {/* PAGE 4: THE BIG BLUE BUTTON */}
      <div className="relative group">
        {/* Glow halo around the button */}
        <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 via-indigo-500 to-cyan-500 rounded-2xl blur-lg opacity-70 group-hover:opacity-100 transition duration-300 animate-pulse pointer-events-none" />

        <button
          id="btn-ai-predict-hotspot"
          onClick={handlePredictClick}
          disabled={isSimulating}
          className="relative w-full py-5 px-6 sm:px-8 rounded-xl bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-700 hover:from-blue-500 hover:via-blue-600 hover:to-indigo-600 active:scale-[0.99] transition-all duration-200 shadow-2xl border-2 border-blue-400 text-white font-display font-black text-lg sm:text-2xl md:text-3xl tracking-wider uppercase flex items-center justify-center gap-3 sm:gap-4 overflow-hidden cursor-pointer"
        >
          {/* Background scanline sweep */}
          <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_0%,rgba(255,255,255,0.2)_50%,transparent_100%)] -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]" />

          {/* AI Neural / Radar Icon */}
          <div className="p-2 sm:p-2.5 rounded-lg bg-blue-950/80 border border-blue-300/60 shadow-inner flex items-center justify-center shrink-0">
            {isSimulating ? (
              <Zap className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-300 animate-spin" />
            ) : (
              <Cpu className="w-6 h-6 sm:w-8 sm:h-8 text-cyan-300 animate-pulse" />
            )}
          </div>

          {/* THE EXACT REQUESTED BUTTON TEXT */}
          <span className="drop-shadow-md text-center">
            AI PREDICT NEXT HOTSPOT - 80% Risk in Sitabuldi
          </span>

          {/* Expand / Collapse Indicator */}
          <div className="shrink-0 p-1.5 rounded-full bg-blue-800/80 text-blue-200">
            {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </div>
        </button>
      </div>

      {/* EXPANDABLE AI INTELLIGENCE & ACTION PANEL */}
      {isExpanded && (
        <div className="rounded-xl bg-zinc-900 border border-zinc-800 p-5 lg:p-6 shadow-2xl transition-all duration-300 animate-in fade-in">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-zinc-800 pb-4 mb-5">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold bg-blue-950 text-blue-300 border border-blue-700">
                  SAFEGRID NEURAL MODEL v3.8
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold bg-red-950 text-red-300 border border-red-800 animate-pulse">
                  PREDICTIVE CONFIDENCE: 94.2%
                </span>
              </div>
              <h4 className="text-xl font-bold text-white font-display mt-1.5">
                Tactical Threat Projection: Sitabuldi Police Station Jurisdiction
              </h4>
              <p className="text-xs text-zinc-400 mt-0.5">
                Algorithmic synthesis of 128 active cases, 310 wiretap intercepts, and mobile tower pings
              </p>
            </div>

            {/* Quick Dispatch Action Button */}
            <div className="flex items-center gap-3 shrink-0">
              {dispatchStatus === 'DISPATCHED' ? (
                <div className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-950/80 border border-emerald-500 text-emerald-300 font-mono-code text-xs font-bold shadow-lg">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>QRT SQUADS DISPATCHED</span>
                </div>
              ) : (
                <button
                  id="btn-dispatch-qrt"
                  onClick={handleDispatch}
                  disabled={dispatchStatus === 'DISPATCHING'}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-red-600 hover:bg-red-500 active:scale-95 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg shadow-red-950/80 font-mono-code cursor-pointer"
                >
                  <Radio className="w-4 h-4 animate-pulse" />
                  {dispatchStatus === 'DISPATCHING' ? 'Mobilizing...' : 'Mobilize QRT Units Now'}
                </button>
              )}
            </div>
          </div>

          {/* 3-Column Intelligence Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6">
            {/* Column 1: Probability & Comparative Hotspot Ranking */}
            <div className="p-4 rounded-lg bg-zinc-950 border border-zinc-800/90 space-y-3">
              <div className="flex items-center justify-between text-xs font-mono-code text-zinc-400">
                <span>ZONAL RISK COMPARISON</span>
                <span className="text-blue-400">MODEL RE-RUN 2M AGO</span>
              </div>

              {/* Sitabuldi 80% Bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-bold text-red-400 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    Sitabuldi PS (Variety Sq.)
                  </span>
                  <span className="font-mono-code font-bold text-red-400">80% RISK</span>
                </div>
                <div className="w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden">
                  <div className="h-full bg-red-600 rounded-full animate-pulse" style={{ width: '80%' }} />
                </div>
              </div>

              {/* Itwari 62% Bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-zinc-300">Itwari Saraf Bazar</span>
                  <span className="font-mono-code text-amber-400">62% ELEVATED</span>
                </div>
                <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-500 rounded-full" style={{ width: '62%' }} />
                </div>
              </div>

              {/* Ganeshpeth 45% Bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-zinc-400">Ganeshpeth CBS Terminal</span>
                  <span className="font-mono-code text-zinc-400">45% MODERATE</span>
                </div>
                <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500/80 rounded-full" style={{ width: '45%' }} />
                </div>
              </div>

              {/* Time Window */}
              <div className="pt-2 border-t border-zinc-800/80 flex items-center justify-between text-xs font-mono-code">
                <span className="text-zinc-400 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-blue-400" />
                  Critical Window:
                </span>
                <span className="text-red-300 font-bold">21:00 - 02:00 HRS</span>
              </div>
            </div>

            {/* Column 2: Key Trigger Drivers */}
            <div className="p-4 rounded-lg bg-zinc-950 border border-zinc-800/90 space-y-2.5">
              <div className="text-xs font-mono-code text-zinc-400 uppercase tracking-wider">
                Key AI Predictive Indicators
              </div>
              <ul className="space-y-2 text-xs text-zinc-300">
                {HOTSPOT_PREDICTION.keyDrivers.map((driver, idx) => (
                  <li key={idx} className="flex items-start gap-2 leading-relaxed">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0" />
                    <span>{driver}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Column 3: Recommended Tactical Counter-measures */}
            <div className="p-4 rounded-lg bg-zinc-950 border border-zinc-800/90 space-y-3">
              <div className="text-xs font-mono-code text-zinc-400 uppercase tracking-wider flex items-center justify-between">
                <span>Recommended Deployment</span>
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              </div>
              
              <div className="text-xs text-zinc-200 bg-zinc-900 p-2.5 rounded border border-zinc-800">
                <div className="font-bold text-white mb-0.5">Asset Allocation:</div>
                <div className="text-blue-300 font-mono-code text-[11px]">
                  {HOTSPOT_PREDICTION.recommendedDeployment.units}
                </div>
              </div>

              <div>
                <div className="text-[11px] font-mono-code text-zinc-400 mb-1">Key Barricade Checkpoints:</div>
                <div className="space-y-1">
                  {HOTSPOT_PREDICTION.recommendedDeployment.checkpoints.map((cp, idx) => (
                    <div key={idx} className="text-[11px] font-mono-code text-zinc-300 flex items-center gap-1.5">
                      <MapPin className="w-3 h-3 text-red-400" />
                      <span>{cp}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
