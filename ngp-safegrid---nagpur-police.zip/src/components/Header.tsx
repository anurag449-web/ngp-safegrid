import React, { useState, useEffect } from 'react';
import { Shield, Radio, Activity, Lock, Bell, RefreshCw, FileText } from 'lucide-react';

interface HeaderProps {
  onRefresh?: () => void;
  onViewReport?: () => void;
  alertCount?: number;
}

export const Header: React.FC<HeaderProps> = ({ onRefresh, onViewReport, alertCount = 3 }) => {
  const [timeString, setTimeString] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const formatted = now.toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      }) + ' ' + now.toLocaleTimeString('en-IN', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      }) + ' IST';
      setTimeString(formatted);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header id="page-header" className="border-b border-zinc-800 bg-zinc-950/90 backdrop-blur-md sticky top-0 z-30 px-4 lg:px-8 py-3.5">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Left: Branding and Subtitle */}
        <div className="flex items-center gap-3.5">
          {/* Official Emblem / Crest Graphic */}
          <div className="relative flex items-center justify-center w-12 h-12 rounded-lg bg-zinc-900 border border-zinc-700 shadow-inner">
            <Shield className="w-7 h-7 text-blue-500" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-black animate-ping" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-black" />
          </div>

          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 id="brand-title" className="text-xl sm:text-2xl font-bold tracking-tight text-white font-display uppercase">
                NGP SafeGrid <span className="text-zinc-400 font-normal">-</span> <span className="text-blue-400">Nagpur Police</span>
              </h1>
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-950/80 border border-blue-800/80 text-blue-300 uppercase font-mono-code tracking-wider">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
                Live Feed
              </span>
            </div>
            <p id="brand-subtitle" className="text-xs sm:text-sm text-zinc-400 font-medium tracking-wide">
              Criminal Network Intelligence Platform
            </p>
          </div>
        </div>

        {/* Right: Telemetry & Controls */}
        <div className="flex items-center flex-wrap gap-2.5 sm:gap-3 text-xs">
          {/* Security Clearance Badge */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 font-mono-code">
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px]">ZONE II & III CRIME INTEL</span>
          </div>

          {/* Real-time Clock */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded bg-zinc-900/90 border border-zinc-800 text-zinc-300 font-mono-code shadow-sm">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span className="text-[11px] font-medium text-emerald-300">{timeString || 'CALIBRATING IST...'}</span>
          </div>

          {/* Live Alerts Bell */}
          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded bg-red-950/50 border border-red-900/70 text-red-300 font-mono-code">
            <Bell className="w-3.5 h-3.5 text-red-400 animate-bounce" />
            <span className="font-semibold text-[11px]">{alertCount} CRITICAL</span>
          </div>

          {/* Quick SitRep button */}
          {onViewReport && (
            <button
              id="sitrep-btn"
              onClick={onViewReport}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-200 transition-colors font-mono-code text-[11px]"
              title="View Daily Intelligence Summary"
            >
              <FileText className="w-3.5 h-3.5 text-blue-400" />
              <span>SitRep</span>
            </button>
          )}

          {/* Quick Refresh */}
          {onRefresh && (
            <button
              id="refresh-btn"
              onClick={onRefresh}
              className="p-1.5 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-400 hover:text-white transition-colors"
              title="Refresh Telemetry"
              aria-label="Refresh Telemetry"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
