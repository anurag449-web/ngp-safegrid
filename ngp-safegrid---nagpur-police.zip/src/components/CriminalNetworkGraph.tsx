import React, { useState } from 'react';
import { Network, PhoneCall, FileText, UserX, AlertTriangle, Crosshair, Users, DollarSign, ShieldAlert, Sparkles } from 'lucide-react';
import { NetworkNode, NetworkEdge } from '../types';
import { NETWORK_NODES, NETWORK_EDGES } from '../data/mockData';

interface CriminalNetworkGraphProps {
  onSelectNode?: (node: NetworkNode) => void;
  selectedNodeId?: string | null;
  nodes?: NetworkNode[];
  edges?: NetworkEdge[];
  newestNodeId?: string | null;
  newestEdgeId?: string | null;
}

export const CriminalNetworkGraph: React.FC<CriminalNetworkGraphProps> = ({
  onSelectNode,
  selectedNodeId,
  nodes = NETWORK_NODES,
  edges = NETWORK_EDGES,
  newestNodeId,
  newestEdgeId,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'calls' | 'firs'>('all');

  // Core Prompt-Mandated Nodes
  const raviNode = nodes.find((n) => n.id === 'node-ravi') || NETWORK_NODES[0];
  const amitNode = nodes.find((n) => n.id === 'node-amit') || NETWORK_NODES[1];
  const sunilNode = nodes.find((n) => n.id === 'node-sunil') || NETWORK_NODES[2];
  const gangNode = nodes.find((n) => n.id === 'node-gang-sitabuldi') || NETWORK_NODES[3];

  // Dynamic Dummy Criminal Nodes
  const vickyNode = nodes.find((n) => n.id === 'node-vicky');
  const poojaNode = nodes.find((n) => n.id === 'node-pooja');
  const rajuNode = nodes.find((n) => n.id === 'node-raju');

  // Edge lookup helpers
  const hasEdge = (edgeId: string) => edges.some((e) => e.id === edgeId);

  return (
    <div id="criminal-network-container" className="h-full flex flex-col rounded-xl bg-zinc-900 border border-zinc-800 shadow-xl overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-zinc-800 bg-zinc-950/60 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 id="network-graph-title" className="text-lg font-bold text-white font-display tracking-wide uppercase flex items-center gap-2">
              <Network className="w-4 h-4 text-red-500" />
              Criminal Network Link
            </h3>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono-code bg-amber-950/80 border border-amber-800/80 text-amber-300 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
              FBI / MCOCA SYNDICATE MAP
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-0.5">
            Inter-connectivity analysis: {nodes.length} Active Targets &amp; {edges.length} Intelligence Links
          </p>
        </div>

        {/* Filter Link Types */}
        <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 rounded p-0.5 text-xs font-mono-code">
          <button
            onClick={() => setFilterType('all')}
            className={`px-2 py-1 rounded transition-colors ${
              filterType === 'all' ? 'bg-zinc-700 text-white font-bold' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            All Links ({edges.length})
          </button>
          <button
            onClick={() => setFilterType('calls')}
            className={`px-2 py-1 rounded transition-colors ${
              filterType === 'calls' ? 'bg-blue-600 text-white font-bold' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Call Records
          </button>
          <button
            onClick={() => setFilterType('firs')}
            className={`px-2 py-1 rounded transition-colors ${
              filterType === 'firs' ? 'bg-red-600 text-white font-bold' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Same FIRs
          </button>
        </div>
      </div>

      {/* Network Canvas (FBI Corkboard & Tactical Link Grid) */}
      <div className="relative flex-1 min-h-[460px] bg-[#08090d] overflow-hidden p-4 select-none">
        {/* Tactical dot-matrix background */}
        <div className="absolute inset-0 bg-dot-matrix opacity-25" />
        
        {/* Subtle Law Enforcement watermark */}
        <div className="absolute bottom-4 right-4 text-right pointer-events-none opacity-20 font-mono-code text-[11px] leading-tight">
          CASE FILE: CR-NGP/2026/MCOCA<br />
          EVIDENCE LINK MATRIX v4.2<br />
          CLASSIFIED // LAW ENFORCEMENT ONLY
        </div>

        {/* Dynamic New Intel Pill Notification */}
        {newestNodeId && (
          <div className="absolute top-3 left-3 z-30 pointer-events-none bg-red-950/90 border border-red-500 text-red-200 px-3 py-1 rounded-md text-xs font-mono-code font-bold flex items-center gap-2 shadow-lg animate-bounce">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>NEW SYNDICATE NODE MAPPED TO EVIDENCE BOARD</span>
          </div>
        )}

        {/* SVG CONNECTOR LINES with FBI Investigation String & Badges */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 600 420" preserveAspectRatio="xMidYMid meet">
          <defs>
            {/* Glowing filter for red lines */}
            <filter id="glow-red" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="3" floodColor="#ef4444" floodOpacity="0.8" />
            </filter>
            <filter id="glow-blue" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="3" floodColor="#3b82f6" floodOpacity="0.8" />
            </filter>
            <filter id="glow-emerald" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="3" floodColor="#10b981" floodOpacity="0.8" />
            </filter>
            <filter id="glow-amber" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="3" floodColor="#f59e0b" floodOpacity="0.8" />
            </filter>
          </defs>

          {/* Line 1: Ravi (Center: 300, 210) to Amit (Top-Left: 120, 95) -> CALL RECORD */}
          {hasEdge('edge-ravi-amit') && (filterType === 'all' || filterType === 'calls') && (
            <g className="transition-opacity duration-200">
              <line x1="300" y1="210" x2="120" y2="95" stroke="#1d4ed8" strokeWidth="4" strokeOpacity="0.3" />
              <line
                x1="300"
                y1="210"
                x2="120"
                y2="95"
                stroke="#3b82f6"
                strokeWidth="2.5"
                strokeDasharray="6,4"
                filter="url(#glow-blue)"
              />
            </g>
          )}

          {/* Line 2: Ravi (Center: 300, 210) to Sunil (Bottom-Left: 120, 325) -> SAME FIR */}
          {hasEdge('edge-ravi-sunil') && (filterType === 'all' || filterType === 'firs') && (
            <g className="transition-opacity duration-200">
              <line x1="300" y1="210" x2="120" y2="325" stroke="#991b1b" strokeWidth="4" strokeOpacity="0.4" />
              <line
                x1="300"
                y1="210"
                x2="120"
                y2="325"
                stroke="#ef4444"
                strokeWidth="3"
                filter="url(#glow-red)"
              />
            </g>
          )}

          {/* Line 3: Ravi (Center: 300, 210) to Gang: Sitabuldi (Right Box: 480, 210) -> SAME FIR */}
          {hasEdge('edge-ravi-gang') && (filterType === 'all' || filterType === 'firs') && (
            <g className="transition-opacity duration-200">
              <line x1="300" y1="210" x2="480" y2="210" stroke="#991b1b" strokeWidth="4" strokeOpacity="0.4" />
              <line
                x1="300"
                y1="210"
                x2="480"
                y2="210"
                stroke="#ef4444"
                strokeWidth="3"
                filter="url(#glow-red)"
              />
            </g>
          )}

          {/* Line 4: Amit (Top-Left: 120, 95) to Gang: Sitabuldi (Right Box: 480, 210) -> CALL RECORD */}
          {hasEdge('edge-amit-gang') && (filterType === 'all' || filterType === 'calls') && (
            <g className="transition-opacity duration-200">
              <path
                d="M 120 95 Q 300 40 480 210"
                fill="none"
                stroke="#2563eb"
                strokeWidth="2"
                strokeDasharray="4,4"
                strokeOpacity="0.7"
              />
            </g>
          )}

          {/* DYNAMIC LINE: Ravi (300, 210) <-> Vicky (480, 76) -> CALL RECORD */}
          {hasEdge('edge-ravi-vicky') && (filterType === 'all' || filterType === 'calls') && (
            <g className="transition-opacity duration-300">
              <line x1="300" y1="210" x2="480" y2="76" stroke="#1d4ed8" strokeWidth="4" strokeOpacity="0.3" />
              <line
                x1="300"
                y1="210"
                x2="480"
                y2="76"
                stroke="#60a5fa"
                strokeWidth="2.5"
                strokeDasharray="6,4"
                filter="url(#glow-blue)"
              />
            </g>
          )}

          {/* DYNAMIC LINE: Amit (120, 95) <-> Pooja (480, 344) -> FINANCIAL CONDUIT */}
          {hasEdge('edge-amit-pooja') && filterType === 'all' && (
            <g className="transition-opacity duration-300">
              <path
                d="M 120 95 Q 300 370 480 344"
                fill="none"
                stroke="#10b981"
                strokeWidth="2.5"
                strokeDasharray="5,4"
                filter="url(#glow-emerald)"
              />
            </g>
          )}

          {/* DYNAMIC LINE: Ravi (300, 210) <-> Raju (300, 59) -> SAME FIR */}
          {hasEdge('edge-ravi-raju') && (filterType === 'all' || filterType === 'firs') && (
            <g className="transition-opacity duration-300">
              <line x1="300" y1="210" x2="300" y2="59" stroke="#991b1b" strokeWidth="4" strokeOpacity="0.4" />
              <line
                x1="300"
                y1="210"
                x2="300"
                y2="59"
                stroke="#ef4444"
                strokeWidth="3"
                filter="url(#glow-red)"
              />
            </g>
          )}

          {/* DYNAMIC LINE: Sunil (120, 325) <-> Vicky (480, 76) -> WEAPONS SUPPLY */}
          {hasEdge('edge-sunil-vicky') && filterType === 'all' && (
            <g className="transition-opacity duration-300">
              <line x1="120" y1="325" x2="480" y2="76" stroke="#d97706" strokeWidth="2" strokeDasharray="4,4" opacity="0.65" />
            </g>
          )}

          {/* DYNAMIC LINE: Pooja (480, 344) <-> Gang (480, 210) -> SAME FIR */}
          {hasEdge('edge-pooja-gang') && (filterType === 'all' || filterType === 'firs') && (
            <g className="transition-opacity duration-300">
              <line x1="480" y1="344" x2="480" y2="210" stroke="#ef4444" strokeWidth="2.5" filter="url(#glow-red)" />
            </g>
          )}
        </svg>

        {/* LINE LABELS (Absolute Positioned HTML Overlays on the lines) */}
        
        {/* Label 1: Call Record (Ravi <-> Amit) */}
        {hasEdge('edge-ravi-amit') && (filterType === 'all' || filterType === 'calls') && (
          <div
            style={{ left: '33%', top: '34%', transform: 'translate(-50%, -50%) rotate(-32deg)' }}
            className="absolute z-10 pointer-events-auto cursor-help"
            title="142 intercepted phone calls logged between Ravi & Amit Seth"
          >
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-blue-950/90 border border-blue-500 text-blue-200 text-[11px] font-mono-code font-bold shadow-lg shadow-blue-950/80 hover:bg-blue-900 transition-colors">
              <PhoneCall className="w-3 h-3 text-blue-400 animate-pulse" />
              <span>Call Record</span>
              <span className="text-[9px] bg-blue-900 px-1 rounded text-white">142x</span>
            </div>
          </div>
        )}

        {/* Label 2: Same FIR (Ravi <-> Sunil) */}
        {hasEdge('edge-ravi-sunil') && (filterType === 'all' || filterType === 'firs') && (
          <div
            style={{ left: '34%', top: '65%', transform: 'translate(-50%, -50%) rotate(33deg)' }}
            className="absolute z-10 pointer-events-auto cursor-help"
            title="Co-accused under FIR #312/2026 MCOCA Sec 3(1)"
          >
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-950/90 border border-red-500 text-red-200 text-[11px] font-mono-code font-bold shadow-lg shadow-red-950/80 hover:bg-red-900 transition-colors">
              <FileText className="w-3 h-3 text-red-400" />
              <span>Same FIR</span>
              <span className="text-[9px] bg-red-800 px-1 rounded text-white">#312/26</span>
            </div>
          </div>
        )}

        {/* Label 3: Same FIR (Ravi <-> Gang: Sitabuldi) */}
        {hasEdge('edge-ravi-gang') && (filterType === 'all' || filterType === 'firs') && (
          <div
            style={{ left: '64%', top: '50%', transform: 'translate(-50%, -50%)' }}
            className="absolute z-10 pointer-events-auto cursor-help"
            title="Syndicate named under FIR #312/2026 & FIR #304/2026"
          >
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-950/90 border border-red-500 text-red-200 text-[11px] font-mono-code font-bold shadow-lg shadow-red-950/80 hover:bg-red-900 transition-colors">
              <FileText className="w-3 h-3 text-red-400" />
              <span>Same FIR</span>
              <span className="text-[9px] bg-red-800 px-1 rounded text-white">MCOCA</span>
            </div>
          </div>
        )}

        {/* Label 4: Call Record (Amit <-> Gang) */}
        {hasEdge('edge-amit-gang') && (filterType === 'all' || filterType === 'calls') && (
          <div
            style={{ left: '50%', top: '10%', transform: 'translate(-50%, -50%)' }}
            className="absolute z-10 pointer-events-auto cursor-help hidden sm:block"
            title="78 outgoing finance coordination calls"
          >
            <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-blue-950/80 border border-blue-600/70 text-blue-300 text-[10px] font-mono-code shadow">
              <PhoneCall className="w-2.5 h-2.5 text-blue-400" />
              <span>Call Record (78 Calls)</span>
            </div>
          </div>
        )}

        {/* DYNAMIC LABEL: Call Record (Ravi <-> Vicky) */}
        {hasEdge('edge-ravi-vicky') && (filterType === 'all' || filterType === 'calls') && (
          <div
            style={{ left: '65%', top: '32%', transform: 'translate(-50%, -50%) rotate(34deg)' }}
            className="absolute z-10 pointer-events-auto cursor-help"
            title="42 encrypted burst calls intercepted (Live Wiretap)"
          >
            <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-blue-950/90 border border-blue-400 text-blue-200 text-[10px] font-mono-code font-bold shadow animate-pulse">
              <PhoneCall className="w-2.5 h-2.5 text-blue-300" />
              <span>Call Record</span>
              <span className="text-[8px] bg-blue-800 px-1 rounded text-white">42x LIVE</span>
            </div>
          </div>
        )}

        {/* DYNAMIC LABEL: Financial Conduit (Amit <-> Pooja) */}
        {hasEdge('edge-amit-pooja') && filterType === 'all' && (
          <div
            style={{ left: '50%', top: '88%', transform: 'translate(-50%, -50%)' }}
            className="absolute z-10 pointer-events-auto cursor-help hidden sm:block"
            title="₹45L digital hawala transfers routed via shell QR accounts"
          >
            <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-950/90 border border-emerald-500 text-emerald-300 text-[10px] font-mono-code font-bold shadow animate-pulse">
              <DollarSign className="w-3 h-3 text-emerald-400" />
              <span>Financial Conduit (₹45L Mules)</span>
            </div>
          </div>
        )}

        {/* DYNAMIC LABEL: Same FIR (Ravi <-> Raju) */}
        {hasEdge('edge-ravi-raju') && (filterType === 'all' || filterType === 'firs') && (
          <div
            style={{ left: '50%', top: '32%', transform: 'translate(-50%, -50%)' }}
            className="absolute z-10 pointer-events-auto cursor-help"
            title="Co-accused under newly amended FIR #312/2026"
          >
            <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-red-950/90 border border-red-500 text-red-200 text-[10px] font-mono-code font-bold shadow">
              <FileText className="w-3 h-3 text-red-400" />
              <span>Same FIR #312/26 (Amended)</span>
            </div>
          </div>
        )}

        {/* ================= NODES ================= */}

        {/* NODE 1: RAVI (MAIN) - IN RED CENTER */}
        <div
          id="node-ravi-main"
          onClick={() => onSelectNode?.(raviNode)}
          style={{ left: '50%', top: '50%', transform: 'translate(-50%, -50%)' }}
          className="absolute z-20 cursor-pointer group"
        >
          {/* Intense red pulsing glow rings */}
          <div className="absolute inset-0 -m-5 rounded-full bg-red-600/30 animate-ping pointer-events-none" />
          <div className="absolute inset-0 -m-3 rounded-full bg-red-600/20 blur-md pointer-events-none" />

          {/* Main Red Circle Node */}
          <div
            className={`relative flex flex-col items-center justify-center w-32 h-32 sm:w-36 sm:h-36 rounded-full bg-gradient-to-b from-red-900 via-red-950 to-black border-3 border-red-500 shadow-2xl shadow-red-900/90 transition-transform duration-200 group-hover:scale-105 ${
              selectedNodeId === 'node-ravi' ? 'ring-4 ring-white' : ''
            }`}
          >
            {/* Classified Tag Badge */}
            <div className="absolute -top-3 px-2 py-0.5 bg-red-600 text-white rounded font-mono-code text-[10px] font-black uppercase tracking-wider shadow-md">
              TARGET ALPHA
            </div>

            {/* Target Crosshair */}
            <Crosshair className="w-5 h-5 text-red-400 mb-1 animate-spin" style={{ animationDuration: '12s' }} />

            {/* Suspect Name */}
            <span className="font-display font-extrabold text-sm sm:text-base text-white text-center tracking-wide uppercase px-2 leading-tight">
              Ravi (Main)
            </span>

            {/* Sub-role & Status */}
            <span className="text-[10px] font-mono-code text-red-200 mt-0.5">Syndicate Kingpin</span>
            <div className="flex items-center gap-1 mt-1">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
              <span className="text-[9px] font-bold font-mono-code bg-red-950 text-red-300 px-1.5 py-0.2 rounded border border-red-800">
                WANTED // MCOCA
              </span>
            </div>
          </div>
        </div>

        {/* NODE 2: AMIT - ITWARI (Top Left) */}
        <div
          id="node-amit-itwari"
          onClick={() => onSelectNode?.(amitNode)}
          style={{ left: '20%', top: '22%', transform: 'translate(-50%, -50%)' }}
          className="absolute z-20 cursor-pointer group"
        >
          <div
            className={`relative flex flex-col items-center justify-center w-26 h-26 sm:w-28 sm:h-28 rounded-full bg-zinc-900 border-2 border-zinc-700 hover:border-blue-400 shadow-xl transition-transform duration-200 group-hover:scale-105 ${
              selectedNodeId === 'node-amit' ? 'ring-3 ring-blue-500 border-blue-400' : ''
            }`}
          >
            <div className="p-1 rounded-full bg-zinc-800 text-blue-400 mb-0.5">
              <UserX className="w-4 h-4" />
            </div>
            <span className="font-display font-bold text-xs sm:text-sm text-zinc-100 text-center px-1 leading-tight">
              Amit - Itwari
            </span>
            <span className="text-[9px] font-mono-code text-zinc-400 mt-0.5">Hawala Conduit</span>
            <span className="text-[8px] font-mono-code text-blue-300 bg-blue-950/80 px-1 rounded mt-0.5">
              142 Wiretaps
            </span>
          </div>
        </div>

        {/* NODE 3: SUNIL - GANESHPETH (Bottom Left) */}
        <div
          id="node-sunil-ganeshpeth"
          onClick={() => onSelectNode?.(sunilNode)}
          style={{ left: '20%', top: '78%', transform: 'translate(-50%, -50%)' }}
          className="absolute z-20 cursor-pointer group"
        >
          <div
            className={`relative flex flex-col items-center justify-center w-26 h-26 sm:w-28 sm:h-28 rounded-full bg-zinc-900 border-2 border-zinc-700 hover:border-amber-400 shadow-xl transition-transform duration-200 group-hover:scale-105 ${
              selectedNodeId === 'node-sunil' ? 'ring-3 ring-amber-500 border-amber-400' : ''
            }`}
          >
            <div className="p-1 rounded-full bg-zinc-800 text-amber-400 mb-0.5">
              <UserX className="w-4 h-4" />
            </div>
            <span className="font-display font-bold text-xs sm:text-sm text-zinc-100 text-center px-1 leading-tight">
              Sunil - Ganeshpeth
            </span>
            <span className="text-[9px] font-mono-code text-zinc-400 mt-0.5">Logistics &amp; Arms</span>
            <span className="text-[8px] font-mono-code text-amber-300 bg-amber-950/80 px-1 rounded mt-0.5">
              FIR #312/2026
            </span>
          </div>
        </div>

        {/* NODE 4: GANG: SITABULDI AS A BOX (Right side) */}
        <div
          id="node-gang-sitabuldi"
          onClick={() => onSelectNode?.(gangNode)}
          style={{ left: '80%', top: '50%', transform: 'translate(-50%, -50%)' }}
          className="absolute z-20 cursor-pointer group"
        >
          {/* Distinctive BOX container as requested */}
          <div
            className={`relative flex flex-col p-3.5 sm:p-4 rounded-xl bg-gradient-to-br from-zinc-900 to-zinc-950 border-2 border-red-600/90 shadow-2xl hover:border-red-400 transition-all duration-200 group-hover:scale-105 w-44 sm:w-50 ${
              selectedNodeId === 'node-gang-sitabuldi' ? 'ring-3 ring-red-500' : ''
            }`}
          >
            {/* Box Header Badge */}
            <div className="flex items-center justify-between border-b border-zinc-800 pb-1.5 mb-1.5">
              <span className="text-[9px] font-mono-code font-bold text-red-400 uppercase tracking-wider flex items-center gap-1">
                <Users className="w-3 h-3 text-red-400" />
                SYNDICATE CELL
              </span>
              <span className="px-1.5 py-0.2 bg-red-950 text-red-300 border border-red-800 rounded text-[9px] font-mono-code">
                BOX-04
              </span>
            </div>

            {/* Box Title */}
            <div className="font-display font-black text-sm sm:text-base text-white tracking-wide uppercase">
              Gang: Sitabuldi
            </div>

            {/* Box Details */}
            <div className="text-[10px] text-zinc-400 mt-1 font-mono-code">
              Jurisdiction: Sitabuldi Market Outer
            </div>

            <div className="mt-2 pt-2 border-t border-zinc-800/80 grid grid-cols-2 gap-1 text-[9px] font-mono-code">
              <div className="bg-zinc-800/80 p-1 rounded text-center">
                <div className="text-zinc-400">Operatives</div>
                <div className="font-bold text-zinc-100">14 Active</div>
              </div>
              <div className="bg-red-950/60 p-1 rounded text-center border border-red-900/50">
                <div className="text-red-300">Docket</div>
                <div className="font-bold text-red-200">#312/26</div>
              </div>
            </div>

            {/* Territorial tag */}
            <div className="mt-2 text-[9px] text-zinc-400 font-mono-code flex items-center justify-between">
              <span>Threat: EXTREME</span>
              <span className="text-red-400 font-bold underline">Inspect Cell &rarr;</span>
            </div>
          </div>
        </div>

        {/* DYNAMIC NODE 5: VICKY - DHARAMPETH (Top-Right) */}
        {vickyNode && (
          <div
            id="node-vicky-dharampeth"
            onClick={() => onSelectNode?.(vickyNode)}
            style={{ left: '80%', top: '18%', transform: 'translate(-50%, -50%)' }}
            className="absolute z-20 cursor-pointer group animate-in fade-in zoom-in duration-300"
          >
            {newestNodeId === 'node-vicky' && (
              <div className="absolute inset-0 -m-3 rounded-full bg-blue-500/40 animate-ping pointer-events-none" />
            )}
            <div
              className={`relative flex flex-col items-center justify-center w-26 h-26 sm:w-28 sm:h-28 rounded-full bg-zinc-900 border-2 ${
                newestNodeId === 'node-vicky' ? 'border-blue-400 ring-4 ring-blue-500/50 scale-105' : 'border-zinc-700 hover:border-blue-400'
              } shadow-xl transition-all duration-200 group-hover:scale-105 ${
                selectedNodeId === 'node-vicky' ? 'ring-3 ring-blue-500 border-blue-400' : ''
              }`}
            >
              {newestNodeId === 'node-vicky' && (
                <div className="absolute -top-3 px-1.5 py-0.2 rounded bg-blue-600 text-white font-mono-code text-[8px] font-bold uppercase shadow">
                  NEW INTEL
                </div>
              )}
              <div className="p-1 rounded-full bg-zinc-800 text-blue-400 mb-0.5">
                <UserX className="w-4 h-4" />
              </div>
              <span className="font-display font-bold text-xs text-zinc-100 text-center px-1 leading-tight">
                Vicky - Dharampeth
              </span>
              <span className="text-[8px] font-mono-code text-zinc-400 mt-0.5">Arms Courier</span>
              <span className="text-[8px] font-mono-code text-blue-300 bg-blue-950/80 px-1 rounded mt-0.5">
                64 Wiretaps
              </span>
            </div>
          </div>
        )}

        {/* DYNAMIC NODE 6: POOJA - SADAR (Bottom-Right) */}
        {poojaNode && (
          <div
            id="node-pooja-sadar"
            onClick={() => onSelectNode?.(poojaNode)}
            style={{ left: '80%', top: '82%', transform: 'translate(-50%, -50%)' }}
            className="absolute z-20 cursor-pointer group animate-in fade-in zoom-in duration-300"
          >
            {newestNodeId === 'node-pooja' && (
              <div className="absolute inset-0 -m-3 rounded-full bg-emerald-500/40 animate-ping pointer-events-none" />
            )}
            <div
              className={`relative flex flex-col items-center justify-center w-26 h-26 sm:w-28 sm:h-28 rounded-full bg-zinc-900 border-2 ${
                newestNodeId === 'node-pooja' ? 'border-emerald-400 ring-4 ring-emerald-500/50 scale-105' : 'border-zinc-700 hover:border-emerald-400'
              } shadow-xl transition-all duration-200 group-hover:scale-105 ${
                selectedNodeId === 'node-pooja' ? 'ring-3 ring-emerald-500 border-emerald-400' : ''
              }`}
            >
              {newestNodeId === 'node-pooja' && (
                <div className="absolute -top-3 px-1.5 py-0.2 rounded bg-emerald-600 text-white font-mono-code text-[8px] font-bold uppercase shadow">
                  NEW INTEL
                </div>
              )}
              <div className="p-1 rounded-full bg-zinc-800 text-emerald-400 mb-0.5">
                <UserX className="w-4 h-4" />
              </div>
              <span className="font-display font-bold text-xs text-zinc-100 text-center px-1 leading-tight">
                Pooja - Sadar
              </span>
              <span className="text-[8px] font-mono-code text-zinc-400 mt-0.5">Cyber &amp; Hawala</span>
              <span className="text-[8px] font-mono-code text-emerald-300 bg-emerald-950/80 px-1 rounded mt-0.5">
                84 Wiretaps
              </span>
            </div>
          </div>
        )}

        {/* DYNAMIC NODE 7: RAJU - TEKDI ROAD (Top-Center) */}
        {rajuNode && (
          <div
            id="node-raju-tekdi"
            onClick={() => onSelectNode?.(rajuNode)}
            style={{ left: '50%', top: '14%', transform: 'translate(-50%, -50%)' }}
            className="absolute z-20 cursor-pointer group animate-in fade-in zoom-in duration-300"
          >
            {newestNodeId === 'node-raju' && (
              <div className="absolute inset-0 -m-3 rounded-full bg-red-500/40 animate-ping pointer-events-none" />
            )}
            <div
              className={`relative flex flex-col items-center justify-center w-26 h-26 sm:w-28 sm:h-28 rounded-full bg-zinc-900 border-2 ${
                newestNodeId === 'node-raju' ? 'border-red-400 ring-4 ring-red-500/50 scale-105' : 'border-zinc-700 hover:border-red-400'
              } shadow-xl transition-all duration-200 group-hover:scale-105 ${
                selectedNodeId === 'node-raju' ? 'ring-3 ring-red-500 border-red-400' : ''
              }`}
            >
              {newestNodeId === 'node-raju' && (
                <div className="absolute -top-3 px-1.5 py-0.2 rounded bg-red-600 text-white font-mono-code text-[8px] font-bold uppercase shadow">
                  NEW INTEL
                </div>
              )}
              <div className="p-1 rounded-full bg-zinc-800 text-red-400 mb-0.5">
                <UserX className="w-4 h-4" />
              </div>
              <span className="font-display font-bold text-xs text-zinc-100 text-center px-1 leading-tight">
                Raju - Tekdi Rd
              </span>
              <span className="text-[8px] font-mono-code text-zinc-400 mt-0.5">Extortion Enforcer</span>
              <span className="text-[8px] font-mono-code text-red-300 bg-red-950/80 px-1 rounded mt-0.5">
                FIR #312/26
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Network Footer Dossier Strip */}
      <div className="p-3 bg-zinc-950 border-t border-zinc-800/80 flex flex-wrap items-center justify-between gap-2 text-xs font-mono-code">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse" />
            <span className="text-zinc-300">Ravi (Main): Apex Controller</span>
          </div>
          <span className="text-zinc-600">|</span>
          <span className="text-zinc-400">Evidence Grade: CDR + MCOCA Dockets</span>
        </div>

        <div className="text-zinc-400 text-[11px] flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>Click any Node to open Full Criminal Dossier</span>
        </div>
      </div>
    </div>
  );
};
