import React from 'react';
import { X, ShieldAlert, PhoneCall, FileText, MapPin, AlertTriangle, Crosshair, Users, Activity } from 'lucide-react';
import { NetworkNode, PoliceStation, CrimeHotspot } from '../types';

interface DossierModalProps {
  node?: NetworkNode | null;
  station?: PoliceStation | null;
  hotspot?: CrimeHotspot | null;
  onClose: () => void;
}

export const DossierModal: React.FC<DossierModalProps> = ({
  node,
  station,
  hotspot,
  onClose,
}) => {
  if (!node && !station && !hotspot) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl bg-zinc-900 border-2 border-zinc-700 rounded-xl shadow-2xl overflow-hidden">
        {/* Top classified banner */}
        <div className="bg-red-950/90 border-b border-red-800 px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-mono-code text-red-300 font-bold uppercase tracking-wider">
            <ShieldAlert className="w-4 h-4 text-red-400" />
            <span>CONFIDENTIAL // NAGPUR POLICE CRIME BRANCH INTELLIGENCE</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-red-300 hover:text-white hover:bg-red-900/60 transition-colors"
            aria-label="Close Dossier"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body: Network Node Case */}
        {node && (
          <div className="p-6 space-y-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold bg-zinc-800 text-zinc-300 uppercase">
                    {node.type}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono-code font-bold uppercase ${
                      node.status === 'WANTED'
                        ? 'bg-red-600 text-white'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}
                  >
                    {node.status}
                  </span>
                  {node.mcoCaBooked && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold bg-red-950 text-red-400 border border-red-800">
                      MCOCA SEC 3(1)
                    </span>
                  )}
                </div>
                <h3 className="text-2xl font-bold font-display text-white mt-1.5 flex items-center gap-2">
                  {node.name}
                </h3>
                {node.alias && (
                  <p className="text-xs font-mono-code text-zinc-400">Alias: "{node.alias}"</p>
                )}
              </div>

              {/* Threat Score Pill */}
              <div className="text-right">
                <span className="text-[10px] font-mono-code text-zinc-400 uppercase">Threat Level</span>
                <div className="text-xl font-bold font-display text-red-400">{node.riskRating}</div>
              </div>
            </div>

            {/* Dossier Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs font-mono-code bg-zinc-950 p-4 rounded-lg border border-zinc-800">
              <div>
                <span className="text-zinc-500 block text-[10px]">ASSIGNED ROLE</span>
                <span className="text-zinc-200 font-semibold">{node.role}</span>
              </div>
              <div>
                <span className="text-zinc-500 block text-[10px]">PRIMARY SECTOR</span>
                <span className="text-zinc-200 font-semibold">{node.location}</span>
              </div>
              <div>
                <span className="text-zinc-500 block text-[10px]">INTERCEPTED CALLS</span>
                <span className="text-blue-400 font-semibold">{node.interceptsLogged} CDR Sessions</span>
              </div>
            </div>

            {/* Linked FIRs */}
            <div>
              <div className="text-xs font-mono-code text-zinc-400 uppercase mb-2 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-red-400" />
                <span>Linked First Information Reports (FIRs):</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {node.firs.map((fir, i) => (
                  <span
                    key={i}
                    className="px-2.5 py-1 rounded bg-zinc-800 border border-zinc-700 text-zinc-200 text-xs font-mono-code"
                  >
                    {fir}
                  </span>
                ))}
              </div>
            </div>

            {/* Field Notes */}
            <div className="bg-zinc-950/80 p-4 rounded-lg border border-zinc-800">
              <div className="text-xs font-mono-code text-zinc-400 uppercase mb-1">
                Intelligence Brief & Field Telemetry:
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed">{node.notes}</p>
            </div>

            {/* Action Bar */}
            <div className="flex items-center justify-end gap-3 pt-2 border-t border-zinc-800">
              <button
                onClick={onClose}
                className="px-4 py-2 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-mono-code transition-colors"
              >
                Close Dossier
              </button>
            </div>
          </div>
        )}

        {/* Content Body: Police Station Case */}
        {station && (
          <div className="p-6 space-y-5">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold bg-blue-950 text-blue-300 border border-blue-800">
                    {station.code}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono-code font-bold uppercase ${
                      station.status === 'HIGH_ALERT' ? 'bg-red-600 text-white animate-pulse' : 'bg-zinc-800 text-zinc-300'
                    }`}
                  >
                    {station.status.replace('_', ' ')}
                  </span>
                </div>
                <h3 className="text-2xl font-bold font-display text-white mt-1.5">
                  {station.name}
                </h3>
                <p className="text-xs font-mono-code text-zinc-400">In-Charge: {station.inCharge}</p>
              </div>

              <div className="text-right">
                <span className="text-[10px] font-mono-code text-zinc-400 uppercase">Emergency Desk</span>
                <div className="text-sm font-bold font-mono-code text-blue-400">{station.phone}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs font-mono-code bg-zinc-950 p-4 rounded-lg border border-zinc-800">
              <div>
                <span className="text-zinc-500 block text-[10px]">ACTIVE PCR PATROLS</span>
                <span className="text-zinc-200 font-bold">{station.activePatrols} Mobilized</span>
              </div>
              <div>
                <span className="text-zinc-500 block text-[10px]">REGISTERED DOCKETS</span>
                <span className="text-red-400 font-bold">{station.currentFIRs} Active Cases</span>
              </div>
            </div>

            <div className="bg-zinc-950/80 p-4 rounded-lg border border-zinc-800">
              <div className="text-xs font-mono-code text-zinc-400 uppercase mb-1">
                Territorial Boundaries & Coverage:
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed">{station.jurisdictionArea}</p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2 border-t border-zinc-800">
              <button
                onClick={onClose}
                className="px-4 py-2 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-mono-code transition-colors"
              >
                Close Station Intel
              </button>
            </div>
          </div>
        )}

        {/* Content Body: Hotspot Case */}
        {hotspot && (
          <div className="p-6 space-y-5">
            <div className="flex items-start justify-between">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold bg-red-950 text-red-300 border border-red-800 uppercase">
                  {hotspot.severity} HOTSPOT
                </span>
                <h3 className="text-2xl font-bold font-display text-white mt-1.5">
                  {hotspot.locationName}
                </h3>
                <p className="text-xs font-mono-code text-zinc-400">Jurisdiction: {hotspot.nearStation}</p>
              </div>

              <div className="text-right">
                <span className="text-[10px] font-mono-code text-zinc-400 uppercase">Threat Score</span>
                <div className="text-2xl font-bold font-display text-red-500">{hotspot.riskScore}%</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs font-mono-code bg-zinc-950 p-4 rounded-lg border border-zinc-800">
              <div>
                <span className="text-zinc-500 block text-[10px]">INCIDENT COUNT (30D)</span>
                <span className="text-zinc-200 font-bold">{hotspot.recentIncidents} Incidents</span>
              </div>
              <div>
                <span className="text-zinc-500 block text-[10px]">CRITICAL TIME WINDOW</span>
                <span className="text-amber-400 font-bold">{hotspot.peakHours}</span>
              </div>
            </div>

            <div className="bg-zinc-950/80 p-4 rounded-lg border border-zinc-800">
              <div className="text-xs font-mono-code text-zinc-400 uppercase mb-1">
                Primary Modus Operandi:
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed">{hotspot.primaryCrimeType}</p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2 border-t border-zinc-800">
              <button
                onClick={onClose}
                className="px-4 py-2 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-mono-code transition-colors"
              >
                Close Hotspot Intel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
