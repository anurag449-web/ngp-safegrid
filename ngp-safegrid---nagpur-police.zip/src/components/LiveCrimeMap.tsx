import React, { useState } from 'react';
import { MapPin, Navigation, AlertCircle, Shield, Eye, Layers, ZoomIn, ZoomOut, Compass } from 'lucide-react';
import { PoliceStation, CrimeHotspot } from '../types';
import { POLICE_STATIONS, CRIME_HOTSPOTS } from '../data/mockData';

interface LiveCrimeMapProps {
  onSelectStation?: (station: PoliceStation) => void;
  onSelectHotspot?: (hotspot: CrimeHotspot) => void;
  selectedStationId?: string | null;
  selectedHotspotId?: string | null;
  stations?: PoliceStation[];
  hotspots?: CrimeHotspot[];
  newestHotspotId?: string | null;
}

export const LiveCrimeMap: React.FC<LiveCrimeMapProps> = ({
  onSelectStation,
  onSelectHotspot,
  selectedStationId,
  selectedHotspotId,
  stations = POLICE_STATIONS,
  hotspots = CRIME_HOTSPOTS,
  newestHotspotId,
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'critical' | 'stations'>('all');
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<'map' | 'list'>('map');

  const filteredHotspots = hotspots.filter((h) => {
    if (activeFilter === 'critical') return h.severity === 'CRITICAL';
    return true;
  });

  return (
    <div id="crime-map-container" className="h-full flex flex-col rounded-xl bg-zinc-900 border border-zinc-800 shadow-xl overflow-hidden">
      {/* Header Bar */}
      <div className="p-4 border-b border-zinc-800 bg-zinc-950/60 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 id="crime-map-title" className="text-lg font-bold text-white font-display tracking-wide uppercase flex items-center gap-2">
              <Navigation className="w-4 h-4 text-blue-400" />
              Live Crime Map - Nagpur
            </h3>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono-code bg-red-950/80 border border-red-800/80 text-red-400">
              HIGH DENSITY GRID
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-0.5">
            Real-time geospatial plotting: Ganeshpeth, Sitabuldi & Kotwali Jurisdictions
          </p>
        </div>

        {/* View toggles and filter */}
        <div className="flex items-center gap-2 text-xs font-mono-code">
          <div className="flex bg-zinc-900 border border-zinc-800 rounded p-0.5">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-2 py-1 rounded transition-colors ${
                activeFilter === 'all' ? 'bg-blue-600 text-white font-bold' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              All Pins
            </button>
            <button
              onClick={() => setActiveFilter('critical')}
              className={`px-2 py-1 rounded transition-colors ${
                activeFilter === 'critical' ? 'bg-red-600 text-white font-bold' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Red Hotspots
            </button>
          </div>

          <div className="hidden sm:flex items-center gap-1 bg-zinc-900 border border-zinc-800 rounded p-0.5">
            <button
              onClick={() => setZoomLevel((z) => Math.min(z + 0.1, 1.3))}
              className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded"
              title="Zoom In"
              aria-label="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel((z) => Math.max(z - 0.1, 0.9))}
              className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded"
              title="Zoom Out"
              aria-label="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Map Canvas Placeholder */}
      <div className="relative flex-1 min-h-[440px] bg-[#07090e] overflow-hidden select-none">
        {/* Tactical Grid Background */}
        <div className="absolute inset-0 bg-tactical-grid opacity-30" />
        
        {/* Radar Sweep Effect */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[520px] h-[520px] rounded-full border border-blue-500/10 pointer-events-none">
          <div className="absolute inset-8 rounded-full border border-blue-500/15" />
          <div className="absolute inset-24 rounded-full border border-blue-500/10" />
          <div className="absolute inset-40 rounded-full border border-blue-500/10" />
          {/* Radar rotating sweep line */}
          <div className="absolute inset-0 animate-radar pointer-events-none opacity-40">
            <div className="w-1/2 h-1/2 bg-gradient-to-br from-blue-500/25 to-transparent origin-bottom-right rounded-tl-full" />
          </div>
        </div>

        {/* Vector Geography & Landmarks of Central Nagpur */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-45" viewBox="0 0 1000 600" preserveAspectRatio="none">
          {/* Nag River line */}
          <path
            d="M 50 380 Q 250 420 450 350 T 800 480 T 980 430"
            fill="none"
            stroke="#1e3a8a"
            strokeWidth="3"
            strokeDasharray="6,4"
          />
          {/* Major arterial road: Central Avenue & Wardha Road */}
          <path d="M 120 180 L 880 190" fill="none" stroke="#27272a" strokeWidth="3" />
          <path d="M 370 40 L 400 580" fill="none" stroke="#27272a" strokeWidth="4" />
          <path d="M 640 50 L 610 550" fill="none" stroke="#27272a" strokeWidth="2.5" />
          <path d="M 220 280 L 780 270" fill="none" stroke="#27272a" strokeWidth="2" />

          {/* Gandhi Sagar Lake vector */}
          <ellipse cx="640" cy="330" rx="42" ry="26" fill="#0c4a6e" fillOpacity="0.4" stroke="#0284c7" strokeWidth="1.5" />
          <text x="640" y="334" fill="#38bdf8" fontSize="11" textAnchor="middle" fontFamily="monospace" opacity="0.8">
            Gandhi Sagar
          </text>

          {/* Sitabuldi Fort Hill representation */}
          <polygon points="340,240 420,220 430,270 350,290" fill="#27272a" fillOpacity="0.5" stroke="#52525b" strokeWidth="1" />
          <text x="385" y="260" fill="#a1a1aa" fontSize="10" textAnchor="middle" fontFamily="monospace" opacity="0.8">
            Sitabuldi Fort
          </text>

          {/* Nagpur Railway Junction Area */}
          <rect x="490" y="210" width="60" height="30" fill="#18181b" stroke="#3f3f46" strokeWidth="1" strokeDasharray="3,3" />
          <text x="520" y="228" fill="#a1a1aa" fontSize="9" textAnchor="middle" fontFamily="monospace">
            NGP JN
          </text>

          {/* Zero Mile Marker */}
          <circle cx="390" cy="205" r="5" fill="#f59e0b" fillOpacity="0.6" />
          <text x="390" y="195" fill="#fbbf24" fontSize="9" textAnchor="middle" fontFamily="monospace">
            Zero Mile
          </text>

          {/* Sector outlines */}
          <circle cx="380" cy="290" r="130" fill="none" stroke="#ef4444" strokeWidth="1" strokeDasharray="4,4" opacity="0.3" />
          <circle cx="620" cy="390" r="110" fill="none" stroke="#3b82f6" strokeWidth="1" strokeDasharray="4,4" opacity="0.2" />
          <circle cx="780" cy="190" r="95" fill="none" stroke="#3b82f6" strokeWidth="1" strokeDasharray="4,4" opacity="0.2" />
        </svg>

        {/* Map Scale & Compass Overlay */}
        <div className="absolute bottom-3 left-3 bg-zinc-950/80 border border-zinc-800 rounded p-2 text-[10px] font-mono-code text-zinc-400 flex items-center gap-3 backdrop-blur-sm z-10">
          <div className="flex items-center gap-1">
            <Compass className="w-3.5 h-3.5 text-blue-400" />
            <span>N 21°08'45" E 79°05'00"</span>
          </div>
          <span className="text-zinc-600">|</span>
          <span className="text-emerald-400">SAT-LINK: ACTIVE</span>
        </div>

        {/* Legend Overlay */}
        <div className="absolute top-3 right-3 bg-zinc-950/85 border border-zinc-800 rounded-lg p-2.5 text-[11px] font-mono-code space-y-1.5 backdrop-blur-sm z-10 shadow-lg">
          <div className="text-[10px] uppercase tracking-wider text-zinc-400 font-bold border-b border-zinc-800 pb-1">
            Tactical Legend
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-blue-500 border border-white flex items-center justify-center text-[8px] text-white font-bold">
              PS
            </span>
            <span className="text-zinc-300">Police Station (3)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-600 animate-pulse border border-red-300" />
            <span className="text-red-400 font-semibold">High Crime Dot</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-amber-500/80" />
            <span className="text-zinc-400">Moderate Crime</span>
          </div>
        </div>

        {/* THE 3 POLICE STATION PINS */}
        {stations.map((station) => {
          const isSelected = selectedStationId === station.id;
          const isSitabuldi = station.id === 'ps-sitabuldi';

          return (
            <div
              key={station.id}
              id={`pin-${station.id}`}
              onClick={() => onSelectStation?.(station)}
              style={{
                left: `${station.xPercent}%`,
                top: `${station.yPercent}%`,
                transform: 'translate(-50%, -100%)',
              }}
              className="absolute z-20 cursor-pointer group transition-all duration-200"
            >
              {/* Pulsing Beacon under station */}
              <div
                className={`absolute left-1/2 top-full -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none ${
                  isSitabuldi
                    ? 'w-16 h-16 bg-red-600/30 animate-ping'
                    : 'w-10 h-10 bg-blue-600/20 animate-pulse'
                }`}
              />

              {/* Station Marker Card / Pin */}
              <div
                className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border shadow-xl transition-transform duration-200 group-hover:scale-110 ${
                  isSitabuldi
                    ? 'bg-red-950 border-red-500 text-white shadow-red-950/80'
                    : isSelected
                    ? 'bg-blue-900 border-blue-400 text-white ring-2 ring-blue-400/40'
                    : 'bg-zinc-900/95 border-blue-600/80 text-zinc-100 hover:border-blue-400'
                }`}
              >
                <div
                  className={`p-1 rounded ${
                    isSitabuldi ? 'bg-red-600 text-white' : 'bg-blue-600 text-white'
                  }`}
                >
                  <Shield className="w-3.5 h-3.5" />
                </div>

                <div className="text-left">
                  <div className="flex items-center gap-1.5">
                    <span className="font-display text-xs font-bold whitespace-nowrap">
                      {station.name}
                    </span>
                    {isSitabuldi && (
                      <span className="px-1 py-0.2 bg-red-600 text-[9px] font-bold rounded animate-pulse font-mono-code">
                        ALERT
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-zinc-300 font-mono-code flex items-center gap-1">
                    <span>{station.activePatrols} Patrols</span>
                    <span>•</span>
                    <span className="text-amber-400">{station.currentFIRs} FIRs</span>
                  </div>
                </div>
              </div>

              {/* Pin Pointer Tail */}
              <div
                className={`w-0 h-0 mx-auto border-l-4 border-l-transparent border-r-4 border-r-transparent border-t-6 ${
                  isSitabuldi ? 'border-t-red-500' : 'border-t-blue-600'
                }`}
              />
            </div>
          );
        })}

        {/* RED DOTS WHERE CRIME IS HIGH */}
        {filteredHotspots.map((hotspot) => {
          const isSelected = selectedHotspotId === hotspot.id;
          const isCritical = hotspot.severity === 'CRITICAL';
          const isNewest = hotspot.id === newestHotspotId;

          return (
            <div
              key={hotspot.id}
              id={`hotspot-${hotspot.id}`}
              onClick={() => onSelectHotspot?.(hotspot)}
              style={{
                left: `${hotspot.xPercent}%`,
                top: `${hotspot.yPercent}%`,
                transform: 'translate(-50%, -50%)',
              }}
              className="absolute z-15 cursor-pointer group"
            >
              {/* Pulsing Red Halo for Crime Hotspot */}
              <div
                className={`absolute inset-0 -m-3 rounded-full animate-ping pointer-events-none ${
                  isNewest
                    ? 'bg-red-500/80 -m-5'
                    : isCritical
                    ? 'bg-red-600/40'
                    : 'bg-amber-500/30'
                }`}
                style={{ animationDuration: isNewest ? '0.8s' : isCritical ? '1.4s' : '2.5s' }}
              />
              <div
                className={`absolute inset-0 -m-1.5 rounded-full pointer-events-none ${
                  isCritical ? 'bg-red-600/50 blur-sm' : 'bg-amber-500/40 blur-sm'
                }`}
              />

              {/* Center Red Dot */}
              <div
                className={`relative w-4 h-4 rounded-full border-2 transition-transform duration-200 group-hover:scale-125 ${
                  isNewest
                    ? 'bg-red-500 border-white ring-4 ring-red-400 scale-125 animate-bounce'
                    : isCritical
                    ? 'bg-red-600 border-white shadow-lg shadow-red-600/80 ring-2 ring-red-600/50'
                    : 'bg-amber-500 border-zinc-900 ring-2 ring-amber-500/50'
                }`}
              />

              {/* Dynamic Tag for newly arrived incident */}
              {isNewest && (
                <div className="absolute left-1/2 -bottom-5 -translate-x-1/2 px-1.5 py-0.2 rounded bg-red-600 text-white font-mono-code text-[8px] font-black uppercase whitespace-nowrap shadow-md pointer-events-none animate-pulse">
                  NEW INCIDENT
                </div>
              )}

              {/* Tooltip on Hover */}
              <div className="absolute left-1/2 -top-2 -translate-x-1/2 -translate-y-full hidden group-hover:block z-30 pointer-events-none min-w-[200px]">
                <div className="bg-zinc-950 border border-red-600/80 rounded-lg p-2 shadow-2xl text-left">
                  <div className="flex items-center justify-between gap-2 border-b border-zinc-800 pb-1 mb-1">
                    <span className="text-[10px] font-mono-code font-bold text-red-400 uppercase">
                      CRIME CONCENTRATION
                    </span>
                    <span className="text-[9px] font-mono-code px-1 bg-red-950 text-red-200 rounded">
                      Risk: {hotspot.riskScore}%
                    </span>
                  </div>
                  <div className="text-xs font-bold text-white">{hotspot.locationName}</div>
                  <div className="text-[10px] text-zinc-400 mt-0.5">{hotspot.primaryCrimeType}</div>
                  <div className="text-[10px] text-zinc-300 font-mono-code mt-1 flex justify-between">
                    <span>Incidents: {hotspot.recentIncidents}</span>
                    <span className="text-red-400">{hotspot.peakHours}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Info Strip with 3 Station Summary */}
      <div className="p-3 bg-zinc-950 border-t border-zinc-800/80 grid grid-cols-3 gap-2 text-center text-xs">
        <div
          onClick={() => onSelectStation?.(stations[0])}
          className="p-2 rounded bg-red-950/40 border border-red-900/60 cursor-pointer hover:bg-red-950/70 transition-colors"
        >
          <div className="font-bold text-red-300 text-xs font-display flex items-center justify-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
            {stations[0]?.name || 'Sitabuldi PS'}
          </div>
          <div className="text-[10px] font-mono-code text-zinc-400 mt-0.5">
            HIGH ALERT // {stations[0]?.currentFIRs || 48} FIRs
          </div>
        </div>

        <div
          onClick={() => onSelectStation?.(stations[1])}
          className="p-2 rounded bg-zinc-900/70 border border-zinc-800 cursor-pointer hover:bg-zinc-800 transition-colors"
        >
          <div className="font-bold text-zinc-200 text-xs font-display">
            {stations[1]?.name || 'Ganeshpeth PS'}
          </div>
          <div className="text-[10px] font-mono-code text-zinc-400 mt-0.5">
            ELEVATED // {stations[1]?.currentFIRs || 34} FIRs
          </div>
        </div>

        <div
          onClick={() => onSelectStation?.(stations[2])}
          className="p-2 rounded bg-zinc-900/70 border border-zinc-800 cursor-pointer hover:bg-zinc-800 transition-colors"
        >
          <div className="font-bold text-zinc-200 text-xs font-display">
            {stations[2]?.name || 'Kotwali PS'}
          </div>
          <div className="text-[10px] font-mono-code text-zinc-400 mt-0.5">
            NORMAL // {stations[2]?.currentFIRs || 22} FIRs
          </div>
        </div>
      </div>
    </div>
  );
};
